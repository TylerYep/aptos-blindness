__version__ = '0.5.3'


from cnn_finetune.contrib.torchvision import *
from cnn_finetune.contrib.pretrainedmodels import *
from cnn_finetune.base import make_model
